<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="ja_JP" sourcelanguage="ja_JP">
<context>
    <name>PhotoLocationByTime</name>
    <message>
        <location filename="../photo_location_by_time.py" line="125" />
        <source>写真位置推定</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../photo_location_by_time.py" line="148" />
        <source>GPXレイヤ選択</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../photo_location_by_time.py" line="148" />
        <source>GPXポイントレイヤを選択:</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../photo_location_by_time.py" line="157" />
        <source>GPXレイヤが選択されていません。</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../photo_location_by_time.py" line="168" />
        <source>GPXレイヤに time フィールドが見つかりません。</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../photo_location_by_time.py" line="186" />
        <source>有効な GPX 時刻ポイントが 2 以上必要です（現在 {} 個）</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../photo_location_by_time.py" line="189" />
        <source>写真フォルダを選択</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../photo_location_by_time.py" line="195" />
        <source>写真フォルダが選択されていません。</source>
        <translation type="unfinished" />
    </message>
</context>
</TS>