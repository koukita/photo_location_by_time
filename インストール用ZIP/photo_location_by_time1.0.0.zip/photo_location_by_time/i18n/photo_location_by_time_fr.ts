<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="fr_FR" sourcelanguage="ja_JP">
    <context>
        <name>PhotoLocationByTime</name>
        <message>
            <location filename="../photo_location_by_time.py" line="125" />
            <source>写真位置推定</source>
            <translation>Estimation de la position des photos</translation>
            </message>
        <message>
            <location filename="../photo_location_by_time.py" line="148" />
            <source>GPXレイヤ選択</source>
            <translation>Sélection de couche GPX</translation>
            </message>
        <message>
            <location filename="../photo_location_by_time.py" line="148" />
            <source>GPXポイントレイヤを選択:</source>
            <translation>Sélectionnez la couche de points GPX :</translation>
            </message>
        <message>
            <location filename="../photo_location_by_time.py" line="157" />
            <source>GPXレイヤが選択されていません。</source>
            <translation>Aucun calque GPX n'est sélectionné.</translation>
            </message>
        <message>
            <location filename="../photo_location_by_time.py" line="168" />
            <source>GPXレイヤに time フィールドが見つかりません。</source>
            <translation>Je ne trouve pas le champ horaire dans la couche GPX.</translation>
            </message>
        <message>
            <location filename="../photo_location_by_time.py" line="186" />
            <source>有効な GPX 時刻ポイントが 2 以上必要です（現在 {} 個）</source>
            <translation>Nécessite au moins 2 points de temps GPX valides (actuellement {})</translation>
            </message>
        <message>
            <location filename="../photo_location_by_time.py" line="189" />
            <source>写真フォルダを選択</source>
            <translation>Sélectionnez le dossier de photos</translation>
            </message>
        <message>
            <location filename="../photo_location_by_time.py" line="195" />
            <source>写真フォルダが選択されていません。</source>
            <translation>Aucun dossier photo n'est sélectionné.</translation>
            </message>
        </context>
    </TS>
